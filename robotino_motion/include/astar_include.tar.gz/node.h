#ifndef NODE_H_
#define NODE_H_

#include <iostream>
#include <iomanip>
#include <queue>
#include <string>
#include <math.h>
#include <ctime>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

class node
{

private:

	const int n=16; // horizontal size of the map
	const int m=16; // vertical size size of the map
	static int map[n][m];
	static int closed_nodes_map[n][m]; // map of closed (tried-out) nodes
	static int open_nodes_map[n][m]; // map of open (not-yet-tried) nodes
	static int dir_map[n][m]; // map of directions
	const int dir=8; // number of possible directions to go at any position
	// if dir==4
	//static int dx[dir]={1, 0, -1, 0};
	//static int dy[dir]={0, 1, 0, -1};
	// if dir==8
	static int dx[dir]={1, 1, 0, -1, -1, -1, 0, 1};
	static int dy[dir]={0, 1, 1, 1, 0, -1, -1, -1};

	static priority_queue<node> pq[2]; // list of open (not-yet-tried) nodes
	static int pqi; // pq index
	static node* n0;
	static node* m0;
	static int i, j, x, y, xdx, ydy;
	static char c;

    // current position
    int xPos;
    int yPos;
    // total distance already travelled to reach the node
    int level;
    // priority=level+remaining distance estimate
    int priority;  // smaller: higher priority

public:
        node();
		node(int xp, int yp, int d, int p);
           
        int getxPos(); 
        int getyPos(); 
        int getLevel(); 
        int getPriority(); 

        void updatePriority(const int & xDest, const int & yDest);

        // give better priority to going strait instead of diagonally
        void nextLevel(const int & i); // i: direction
        
        // Estimation function for the remaining distance to the goal.
        const int & estimate(const int & xDest, const int & yDest);
        
        bool operator<(const node & a, const node & b);
        
        string pathFind( const int & xStart, const int & yStart, 
                 const int & xFinish, const int & yFinish );
                 
                 
       
};

#endif /* NODE_H_ */
