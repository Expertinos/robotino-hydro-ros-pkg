/*
 * MapSearchNode.h
 *
 *  Created on: 15/10/2014
 *      Author: expertinos.unifei@gmail.com
 */

#ifndef MAPSEARCHNODE_H_
#define MAPSEARCHNODE_H_

#include "stlastar.h"
#include <iostream>
#include <stdio.h>
#include <queue>

#define DEBUG_LISTS 0
#define DEBUG_LIST_LENGTHS_ONLY 0

using namespace std;

class MapSearchNode
{
public:

	MapSearchNode();
	MapSearchNode( int px, int py );

	float GoalDistanceEstimate( MapSearchNode &nodeGoal );
	bool IsGoal( MapSearchNode &nodeGoal );
	bool GetSuccessors( AStarSearch<MapSearchNode> *astarsearch, MapSearchNode *parent_node );
	float GetCost( MapSearchNode &successor );
	bool IsSameState( MapSearchNode &rhs );

	void PrintNodeInfo();
	int astar();
	//int GetMap( int x, int y );
	void fila();

	queue<int> queue_astar;

private:
	int x;	 // the (x,y) positions of the node
	int y;
	int xmov, ymov;
	int xinit, yinit;
	int xtraj,ytraj;

	int v_base[2]; //valor que servir� de compara��o para saber se ou x ou y sofreram altera��es. Ser� sempre o 1� valor
	int v_aux[2]; //valor que subtrair� de v_base para saber se houve altera��o de x e/ou y
	int comando[2];
	int res;
	int resx;
	int resy;

//	int world_map[ MAP_WIDTH ][ MAP_HEIGHT ];

	queue<int> queue_temp;


};

#endif /* MAPSEARCHNODE_H_ */
